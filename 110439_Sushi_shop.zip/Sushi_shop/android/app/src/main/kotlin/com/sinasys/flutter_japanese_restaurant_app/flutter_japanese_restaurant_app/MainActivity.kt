package com.sinasys.flutter_japanese_restaurant_app.flutter_japanese_restaurant_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
