import 'package:flutter_japanese_restaurant_app/src/model/food.dart';

class FoodCategory {
  final FoodType type;
  bool isSelected;

  FoodCategory(this.type, this.isSelected);
}
