class AppAsset {
  const AppAsset._();

  static const sushi1 = "assets/images/sushi1.png";
  static const sushi2 = "assets/images/sushi2.png";
  static const sushi3 = "assets/images/sushi3.png";
  static const sushi4 = "assets/images/sushi4.png";
  static const sushi5 = "assets/images/sushi5.png";
  static const sushi6 = "assets/images/sushi6.png";
  static const sushi7 = "assets/images/sushi7.png";
  static const sushi8 = "assets/images/sushi8.png";
  static const sushi9 = "assets/images/sushi9.png";
  static const sushi10 = "assets/images/sushi10.png";
  static const sushi11 = "assets/images/sushi11.png";
  static const sushi12 = "assets/images/sushi12.png";
  static const profileImage = "assets/images/profile_pic.png";
  static const githubImage = "assets/images/github_pic.png";
  static const emptyCart = "assets/images/empty_cart.png";
  static const emptyFavorite = "assets/images/empty_favorite.png";
}
