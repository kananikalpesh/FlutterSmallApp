import 'package:flutter/material.dart';

class AppColor {
  const AppColor._();

  static const lightOrange = Color(0xFFFAA33C);
  static const lightBlack = Color(0xFF101725);
}
