import 'package:flutter/material.dart';

class FurnitureColor {
  Color color;
  bool isSelected;

  FurnitureColor({required this.color, this.isSelected = false});
}
