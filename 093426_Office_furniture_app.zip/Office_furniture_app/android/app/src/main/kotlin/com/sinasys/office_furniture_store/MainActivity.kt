package com.sinasys.office_furniture_store

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
