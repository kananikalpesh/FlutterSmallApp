import 'package:flutter/material.dart';

const kprimaryTextColor = Color(0xff0D253C);
const ksecondaryTextColor = Color(0xff2D4379);
const kprimaryColor = Color(0xFF376AED);
const kgreyColor = Color(0xff7B8BB2);
const kbackgroundColor = Color(0xFFFBFBFF);
