import 'package:flutter/material.dart';

const kprimarycolor = Color(0xff2ba7db);
