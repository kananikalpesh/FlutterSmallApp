package com.example.flutter_animated_starter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
