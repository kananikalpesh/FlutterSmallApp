package com.example.social_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
