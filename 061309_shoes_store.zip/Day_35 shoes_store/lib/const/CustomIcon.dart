import 'package:flutter/material.dart';

class CustomIcons {
  static const IconData favorite = IconData(0xe900, fontFamily: "CustomIcon");
  static const IconData search = IconData(0xe901, fontFamily: "CustomIcon");
  static const IconData cart = IconData(0xe903, fontFamily: "CustomIcon");
}
