// ignore: file_names
List<Map> paintings = [
  {
    'image': 'assets/painting6.jpeg',
    'name': 'The Sower',
  },
  {
    'image': 'assets/painting2.jpg',
    'name': 'The Starry Night',
  },
  {
    'image': 'assets/painting3.jpg',
    'name': 'The Potato Eaters',
  },
  {
    'image': 'assets/painting4.jpg',
    'name': 'Irises',
  },
  {
    'image': 'assets/painting5.jpg',
    'name': 'Starry Night Over the Rhône',
  },
  {
    'image': 'assets/painting7.jpg',
    'name': 'Landscape with Snow',
  },
  {
    'image': 'assets/painting8.jpg',
    'name': 'The Night Café',
  },
];
