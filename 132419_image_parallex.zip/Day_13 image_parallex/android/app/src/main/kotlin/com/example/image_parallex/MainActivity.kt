package com.example.image_parallex

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
