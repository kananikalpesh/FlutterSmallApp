part of 'router.dart';

abstract class Routes {
  static const login = "login";
  static const import = "import";
  static const home = "home";
}
