package com.example.food_delivery

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
