package com.example.course_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
